
const shoppingList = [
  { item: "Ous", quantity: 2, units: ["dotzena", "dotzenes"] },
  { item: "Llet", quantity: 1, units: ["litre", "litres"] },
  { item: "Oli", quantity: 2, units: ["litre", "litres"] },
	/*...*/
  { item: "Patates", quantity: 15, units: ["kilogram", "kilograms"] },
];
